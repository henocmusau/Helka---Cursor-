export default {
  reactStrictMode: true
};