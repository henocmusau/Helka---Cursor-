# TP Helka – Site (boilerplate)
Contenu généré: structure complète minimaliste prête à être étendue.

## Démarrer localement
1. Copier `.env.local.example` -> `.env.local` et remplir.
2. `pnpm install`
3. `pnpm db:generate && pnpm db:migrate`
4. `pnpm dev`

--- 
Les pages et composants sont des squelettes basés sur la spécification fournie. Remplacez les placeholders par des requêtes Drizzle et mettez en place les clés externes (Supabase, Resend).
